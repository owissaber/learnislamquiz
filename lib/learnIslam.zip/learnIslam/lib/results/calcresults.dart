class Result {
  List<String> images = [
    'images/success.png',
    'images/good.png',
    'images/bad.png',
  ];
  String message;
  String image;
  getImage(marks) {
    if (marks < 5) {
      image = images[2];
    } else if (marks < 8) {
      image = images[1];
    } else {
      image = images[0];
    }
    return image;
  }

  getMessage(marks) {
    if (marks < 5) {
      return 'يجب ان تحاول مرة اخري ...\n' + ' لقد حصلت علي $marks';
    } else if (marks < 8) {
      return 'من ان الممكن ان تكون افضل  ...\n' + ' لقد حصلت علي  $marks';
    } else {
      return 'ممتاز احسنت ...\n' + ' لقد حصلت علي $marks';
    }
  }
}
