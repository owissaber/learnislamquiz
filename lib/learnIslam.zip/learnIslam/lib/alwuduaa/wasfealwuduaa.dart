import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:learnislam/home.dart';

import 'alwuduaapage.dart';

class WasfAlwuduaa extends StatefulWidget {
  @override
  _WasfElSalahState createState() => _WasfElSalahState();
}

class _WasfElSalahState extends State<WasfAlwuduaa> {
  String title = ' باب الوضوء ';
  List<String> muqadima = [
    'يُعرَّف الوضوء (بضمّ الواو) في اللغة بأنّه: مصدرٌ مأخوذٌ من الوضاءة؛ وهي الحُسن، والنظافة، والجمال، وفي الاصطلاح الشرعيّ: هو اسمٌ لغسل أعضاء مخصوصة، بكيفيّةٍ مخصوصةٍ'
        'وقد أجمع العلماء على وجوب الطهارة بالوضوء، أو الغسل للصلاة، وغيرها من العبادات، والدليل على ذلك قول الله -تعالى-: (يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ وَامْسَحُوا بِرُءُوسِكُمْ وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ)،[٣] وقوله: (يَا أَيُّهَا الَّذِينَ آمَنُوا لَا تَقْرَبُوا الصَّلَاةَ وَأَنتُمْ سُكَارَىٰ حَتَّىٰ تَعْلَمُوا مَا تَقُولُونَ وَلَا جُنُبًا إِلَّا عَابِرِي سَبِيلٍ حَتَّىٰ تَغْتَسِلُوا وَإِن كُنتُم مَّرْضَىٰ أَوْ عَلَىٰ سَفَرٍ أَوْ جَاءَ أَحَدٌ مِّنكُم مِّنَ الْغَائِطِ أَوْ لَامَسْتُمُ النِّسَاءَ فَلَمْ تَجِدُوا مَاءً فَتَيَمَّمُوا صَعِيدًا طَيِّبًا فَامْسَحُوا بِوُجُوهِكُمْ وَأَيْدِيكُمْ)'
        ''
        ''
        ''
        ''
  ];
  //كيفية الوضوء
  List<String> wasfElWuduaa = [
    'كيفيّة الوضوء تتضمّن فرائضَ وسنناً سيأتي بيان أحكامها بالتفصيل بعنوان: أركان وسنن الوضوء، لكن الصفة العامة للوضوء الصحيح كما يأتي: حيث يستحضر المسلم النية قبل الوضوء، فلا يصحّ الوضوء إلّا بنية رفع الحدث الذي منع من العبادة، ثم يسمّي الله، فيغسل كفّيه ثلاث مرّات؛ وحكم غسل الكفين ثلاث مرّاتٍ سنة، والدليل هو حديث عثمان بن عفان رضي الله عنه، الذي يتضمّن صفة وضوء الرسول عليه الصلاة والسلام، حيث قال: (دعا بوَضوءٍ، فتوضأ، فغسل كَفَّيْهِ ثلاثَ مراتٍ)،[٦] وقد صرف غسل الكفين عن الوجوب عدم ذكر الله -تعالى- لها في قوله: (يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ وَامْسَحُوا بِرُءُوسِكُمْ وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ)،[٧] وبعد ذلك يتمضمض ويستنشق، وتعرّف المضمضة بأنّها إدارة الماء في الفم، أمّا الاستنشاق فهو اجتذاب الماء بالنفس، فقد ورد في حديث عثمان -رضي الله عنه- في صفة وضوء النبي عليه الصلاة والسلام، حيث قال: (فمضمض واستنثر، ثمّ غسل وجهَه ثلاثَ مراتٍ)،[٦] ويُستحبّ تكرار المضمضة والاستنشاق ثلاث مرّاتٍ.'
        'ثم يغسل المسلم وجهه، وحدوده من أعلى الجبهة إلى أسفل اللحية طولاً، ومن الأذن إلى الأذن عرضاً، ويُستحبّ غسله ثلاث مرّاتٍ، لحديث عثمان -رضي الله عنه- في صفة وضوء النبي عليه الصلاة والسلام، حيث قال: (ثم غسل وجهَه ثلاثَ مراتٍ)،[٦] ثم يغسل المسلم يديه إلى المرفقين، ويكون الغسل من الأصابع إلى المرفق، ويستحبّ غسلها ثلاث مرات لحديث عثمان -رضي الله عنه- في صفة وضوء النبي عليه الصلاة والسلام، حيث قال: (ثم غسل يدَه اليُمْنَى إلى المِرفَقِ ثلاثَ مراتٍ، ثم غسل يدَه اليُسْرَى مِثْلَ ذلك)،[٦] ثم يمسح المسلم رأسه، ويمسح أذنيه، وبعد ذلك يغسل قدميه، ويستحبّ ثلاث مرات لحديث عثمان -رضي الله عنه- في صفة وضوء النبي عليه الصلاة والسلام، حيث قال: (ثم غسل رجلَه اليُمنَى إلى الكعبين ثلاثَ مراتٍ، ثم غسل اليُسرَى مِثْلَ ذلك)، ويدعو بعد الانتهاء بالدعاء المأثور عن النبي صلى الله عليه وسلم'
  ];

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: missing_return
      onWillPop: () {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => HomePage()));
      },
      child: SafeArea(
        child: Scaffold(
          body: Column(
            children: <Widget>[
              Expanded(
                flex: 8,
                child: ListView(
                  children: <Widget>[
                    Container(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: <Widget>[
                              //العنوان
                              Text(
                                title,
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontSize: 35.0,
                                ),
                              ),
                              //مقدمة
                              Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Container(
                                  padding: EdgeInsets.all(10.0),
                                  alignment: Alignment.topRight,
                                  child: Text(
                                    muqadima[0],
                                    textDirection: TextDirection.rtl,
                                    //  textAlign: TextAlign.right,
                                    style: TextStyle(fontSize: 25),
                                  ),
                                ),
                              ),
                              Container(
                                color: Colors.green,
                                child: Text(
                                  'كيفية الوضوء',
                                  style: TextStyle(
                                    fontSize: 35.0,
                                  ),
                                ),
                              ),
                              //الشرح
                              Container(
                                margin: EdgeInsets.all(20),
                                padding: EdgeInsets.only(
                                    top: 5, left: 20, right: 20, bottom: 15),
                                child: Center(
                                  child: Text(
                                    wasfElWuduaa[0],
                                    textAlign: TextAlign.right,
                                    style: TextStyle(fontSize: 20),
                                  ),
                                ),
//                        decoration: BoxDecoration(
//                            gradient: LinearGradient(
//                          colors: [Colors.grey[100], Colors.grey[200]],
//                        )),
                              ),
                              Container(
                                color: Colors.green,
                                child: Text(
                                  'والله أعلم وصلى الله وسلم على نبينا محمد وعلى آله وصحبه أجمعين .',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 25.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      RaisedButton(
                        color: Colors.green,
                        textColor: Colors.white,
                        child: Text(
                          'الاسئلة',
                          style: TextStyle(
                              fontSize: 25,
                              color: Colors.black87,
                              fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => AlwuduaaPage5()));
                        },
                      ),
                      RaisedButton(
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => HomePage()));
                        },
                        color: Colors.green,
                        child: Text(
                          'الصفحة الرئيسية',
                          style: TextStyle(
                              fontSize: 25,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  color: Color(0xFF9E9D24),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
