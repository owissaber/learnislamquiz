import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:learnislam/home.dart';
import 'package:learnislam/results/calcresults.dart';

import 'file:///D:/Flutter%20SDK/angelaprojects/learnislam/lib/results/resultpage.dart';

// ignore: camel_case_types
class MyQuizPageAlhag extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
          future:
              DefaultAssetBundle.of(context).loadString('assets/alhag.json'),
          builder: (context, snapshot) {
            var myData = jsonDecode(snapshot.data.toString());
            if (myData == null) {
              return Scaffold(
                body: Center(
                  child: Text(
                    "loading",
                  ),
                ),
              );
            } else {
              return QuizPage(myData: myData);
            }
          }),
    );
  }
}

// ignore: must_be_immutable
class QuizPage extends StatefulWidget {
  var myData;
  QuizPage({Key key, @required this.myData}) : super(key: key);
  @override
  _QuizPageState createState() => _QuizPageState(myData);
}

class _QuizPageState extends State<QuizPage> {
  var myData;
  _QuizPageState(this.myData);

  Color colorToShow = Colors.indigoAccent;
  Color right = Colors.green;
  Color wrong = Colors.red;
  int marks = 0;
  int i = 1;
  int timer = 30;
  int index = 1;
  int indexRight = 0;
  int indexWrong = 0;
  int questionNumber = 10;
  String showTimer = '30';
  bool cancelTimer = false;

  Map<String, Color> btnColor = {
    "a": Colors.indigoAccent,
    "b": Colors.indigoAccent,
//    "c": Colors.indigoAccent,
//    "d": Colors.indigoAccent,
  };

  void nextQuestion() {
    cancelTimer = false;
    timer = 30;
    setState(() {
      if (i < questionNumber) {
        //لعرض الاسئلة بطول الجيسون
        //عدد الاسئلة
        i++;
        index = index + 1;

        startTimer();
      } else {
        Result res = Result();
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => ResultPage(
            image: res.getImage(marks),
            message: res.getMessage(marks),
            myData: myData,
          ),
        ));
      }
      btnColor['a'] = Colors.indigoAccent;
      btnColor['b'] = Colors.indigoAccent;
//      btnColor['c'] = Colors.indigoAccent;
//      btnColor['d'] = Colors.indigoAccent;
    });
  }

  void checkAnswer(String k) {
    //لمعرفة هل الاجابة صحيحة ام لا
    if (myData[2][i.toString()] == myData[1][i.toString()][k]) {
      marks = marks + 1;
      colorToShow = right;
      indexRight += 1;
    } else {
      colorToShow = wrong;
      indexWrong += 1;
    }
    setState(() {
      btnColor[k] = colorToShow;
      cancelTimer = true;
    });

    Timer(Duration(seconds: 2), nextQuestion);
  }

  void startTimer() {
    const onesec = Duration(seconds: 1);
    Timer.periodic(onesec, (Timer t) {
      setState(() {
        if (timer < 1) {
          t.cancel();
          indexWrong += 1;
          nextQuestion();
        } else if (cancelTimer == true) {
          t.cancel();
        } else {
          timer = timer - 1;
        }
        showTimer = timer.toString();
      });
    });
  }

  @override
  void initState() {
    startTimer();
    super.initState();
  }

  Widget choicbutton(String k) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: 10.0,
        horizontal: 20.0,
      ),
      child: MaterialButton(
        onPressed: () => checkAnswer(k),
        child: Text(
          myData[1][i.toString()][k],
          textAlign: TextAlign.right,
          style: TextStyle(
            color: Colors.white,
            fontSize: 25.0,
            fontFamily: 'Alike',
          ),
          maxLines: 2,
        ),
        color: btnColor[k],
        minWidth: MediaQuery.of(context).size.width,
        height: 40.0,
        highlightColor: Colors.indigo[700],
        splashColor: Colors.indigo[700],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitDown, DeviceOrientation.portraitUp]);
    return WillPopScope(
      onWillPop: () {
        return showDialog(
            //ينفذ هذا الامر عند الضغط علي مفتاح العودة في الموبايل فيقوم باظهار رساله
            context: context,
            builder: (context) => AlertDialog(
                  title: Text(
                    'تعلم الاسلام ',
                    textAlign: TextAlign.center,
                  ),
                  content: Text(
                    'هل تريد العودة لاختيار مستوي  ',
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 25.0),
                  ),
                  actions: <Widget>[
                    FlatButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('البقاء في الاختبار'),
                    ),
                    FlatButton(
                      onPressed: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (context) => HomePage()));
                      },
                      child: Text('العودة لاختيار مستوي'),
                    ),
                  ],
                ));
      },
      child: SafeArea(
        child: Scaffold(
          body: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Flexible(
                  // flex: 1,
                  child: Container(
                    //color: Colors.brown[300],
                    // alignment: Alignment.bottomRight,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            Text(
                              '✔ : $questionNumber/$indexRight',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 22.0,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              '✖ : $questionNumber/$indexWrong',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 22.0,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            //  color: Colors.brown[300],
                            alignment: Alignment.topCenter,
                            child: CircleAvatar(
                              maxRadius: 20,
                              child: Text(
                                showTimer,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 28.0,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 15.0,
                          ),
                          child: Column(
                            children: <Widget>[
                              Text(
                                '$questionNumber/$index',
                                style: TextStyle(
                                  fontSize: 22.0,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                'قسم الحج ',
                                style: TextStyle(
                                  fontSize: 22.0,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: <Color>[
                          Color(0xFF006064),
                          Color(0xFF006064),
                        ],
                      ),
                    ),
                    //padding: EdgeInsets.all(16.0),

                    child: Container(
                      margin: EdgeInsets.all(20.0),
                      alignment: Alignment.center,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25.0),
                        child: Text(
                          myData[0][i.toString()],
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 28.0,
                              fontFamily: 'Scheherazade',
                              fontWeight: FontWeight.w700,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment(0.7, 0.0),
                      colors: [
                        const Color(0xFFFFFFEE),
                        const Color(0xFF999999)
                      ], // whitish to gray
                      tileMode: TileMode
                          .repeated, // repeats the gradient over the canvas
                    )),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        choicbutton('a'),
                        choicbutton('b'),
//                      choicbutton('c'),
//                      choicbutton('d'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
