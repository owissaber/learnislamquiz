const kKeepMeLoggedIn = 'kKeepMeLoggedIn';
