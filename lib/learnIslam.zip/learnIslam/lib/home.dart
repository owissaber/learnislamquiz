import 'dart:io';

import 'package:firebase_admob/firebase_admob.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:learnislam/about.dart';
import 'package:learnislam/level_5/quizpage5.dart';

import 'alhag/wasfalhag.dart';
import 'alsalah/wasfelsalah.dart';
import 'alsiyam/wasfalsiyam.dart';
import 'alwuduaa/wasfealwuduaa.dart';
import 'level_1/quizpage1.dart';
import 'level_2/quizpage2.dart';
import 'level_3/quizpage3.dart';
import 'level_4/quizpage4.dart';
import 'level_6/quizpage6.dart';

const String testDevice = "";

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static final MobileAdTargetingInfo targetingInfo = new MobileAdTargetingInfo(
    //لاضافة الاعلانات للتطبيق في هذه الصفحة
    testDevices: testDevice != null ? <String>[testDevice] : null,
    keywords: <String>['background', 'books'],
    birthday: DateTime.now(),
    childDirected: true,
    nonPersonalizedAds: true,
  );
  BannerAd showBannerAd() {
    return BannerAd(
      adUnitId: BannerAd.testAdUnitId,
      size: AdSize.banner,
      targetingInfo: targetingInfo,
      listener: (MobileAdEvent event) {
        print("BannerAd event $event");
      },
    );
  }

  BannerAd _bannerAd;
  InterstitialAd _interstitialAd;
  List<String> images = [
    'images/iam1.jpg',
    'images/iam2.jpg',
    'images/iam3.jpg',
    'images/iam4.jpg',
  ];
  Widget customCard(String name, String img) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => Level_Oun()),
          );
        },
        child: Material(
          color: Colors.indigoAccent,
          elevation: 10.0,
          borderRadius: BorderRadius.circular(20.0),
          child: Container(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                  child: Material(
                    borderRadius: BorderRadius.circular(100.0),
                    elevation: 5.0,
                    child: Container(
                      width: 200.0,
                      height: 200.0,
                      child: ClipOval(
                        child: Image(
                          fit: BoxFit.cover,
                          image: AssetImage(
                            img,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Text(
                    name,
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontFamily: 'Quando',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
//                Padding(
//                  padding: const EdgeInsets.all(20.0),
//                  child: Text(
//                    'aasadad adadadad adadada adada dadddd dddddddd dddddddd ',
//                    style: TextStyle(
//                      fontSize: 18.0,
//                      color: Colors.white,
//                      fontFamily: 'Alike',
//                    ),
//                    //  maxLines: 5,لجعل العدد الاقصي هو 5 اسطر فقط
//                    textAlign: TextAlign.left,
//                  ),
//                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations(
        //حتي تجعل الشاشة لا تلف
        [DeviceOrientation.portraitDown, DeviceOrientation.portraitUp]);

    return WillPopScope(
      // ignore: missing_return
      onWillPop: () {
        return showDialog(
            //ينفذ هذا الامر عند الضغط علي مفتاح العودة في الموبايل فيقوم باظهار رساله
            context: context,
            builder: (context) => AlertDialog(
                  title: Text(
                    'ثقف نفسك دينياًٌ',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.green),
                  ),
                  content: Text(
                    'خروج  ',
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 25.0),
                  ),
                  actions: <Widget>[
                    FlatButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('البقاء في البرنامج'),
                    ),
                    FlatButton(
                      onPressed: () {
                        exit(0);
                      },
                      child: Text(
                        'الخروج من البرنامج',
                      ),
                    ),
                  ],
                ));
      },
      child: SafeArea(
        child: Scaffold(
          drawer: Drawer(
            child: Container(
              color: Color(0xFFAFB42B),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    DrawerHeader(
                      child: Image.asset(
                        'images/logo.jpg',
                        fit: BoxFit.fill,
                      ),
                    ),
                    ListTile(),

                    Card(
                      child: ListTile(
                        title: Center(
                          child: Text(
                            "عن التطبيق ",
                            style: TextStyle(
                              fontSize: 25.0,
                            ),
                          ),
                        ),
                        onTap: () {
                          Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                  builder: (context) => AboutApp()));
                        },
                      ),
                    ),
                    ListTile(),
                    ListTile(),
                    Card(
                      color: Colors.red[900],
                      child: ListTile(
                          title: Text(
                            'خروج',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          onTap: () {
                            exit(0);
                          }),
                    ) //للخروج من البرنامج} ,)
                  ],
                ),
              ),
            ),
          ),
          backgroundColor: Color(0xFF827717),
          appBar: AppBar(
              actions: <Widget>[],
              backgroundColor: Color(0xFFAFB42B),
              title: Text(
                'إختر المستوي ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 25.0,
                  fontFamily: "Cairo",
                ),
              ),
              centerTitle: true),
          body: ListView(
            children: <Widget>[
              MaterialLevel(
                  label: 'قسم الصلاة ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => WasfElSalah()));
                  }),
              MaterialLevel(
                  label: 'قسم الوضوء ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) => WasfAlwuduaa()));
                  }),
              MaterialLevel(
                  label: 'قسم الحج ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => WasfAlhag()));
                  }),
              MaterialLevel(
                  label: 'صيام شهر رمضان ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => WasfAlsiyam()));
                  }),
              MaterialLevel(
                  label: 'المستوي الاول ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => Level_Oun()));
                  }),
              MaterialLevel(
                  label: 'المستوي الثاني ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => Level_Tow()));
                  }),
              MaterialLevel(
                  label: 'المستوي الثالث ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => QuizPage3()));
                  }),
              MaterialLevel(
                  label: 'المستوي الرابع ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => Level_Four()));
                  }),
              MaterialLevel(
                  label: 'المستوي الخامس ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => Level_Five()));
                  }),
              MaterialLevel(
                  label: 'المستوي السادس ',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => Level_Six()));
                  }),
              // MaterialLevel(
              //     label: 'المستوي السابع ',
              //     onPressed: () {
              //       Navigator.of(context).pushReplacement(
              //           MaterialPageRoute(builder: (context) => Level_Seven()));
              //     }),

//
            ],
          ),
        ),
      ),
    );
  }
}

class MaterialLevel extends StatelessWidget {
  final String label;
  final Function onPressed;

  const MaterialLevel({Key key, @required this.label, @required this.onPressed})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        top: 20.0,
        right: 35,
        left: 35,
      ),
      child: MaterialButton(
        elevation: 15.0,
        onPressed: onPressed,
        color: Color(0xFFE6EE9e),
        //minWidth: 70.0,
        height: 60.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 25.0,
            color: Color(0xFF004D40),
            fontFamily: 'Satisfy',
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
