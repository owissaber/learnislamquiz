import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../home.dart';

// ignore: must_be_immutable
class ResultLevel7 extends StatefulWidget {
  String message;
  String image;
  int marks;
  var myData;
  ResultLevel7({@required this.message, this.image, this.myData});
  @override
  _ResultPageState createState() => _ResultPageState(message, image, myData);
}

class _ResultPageState extends State<ResultLevel7> {
  String message;
  String image;
  var myData;
  _ResultPageState(this.message, this.image, this.myData);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          actions: <Widget>[],
          title: Text('النتيجة'),
          centerTitle: true,
        ),
        body: Column(
          children: <Widget>[
            Expanded(
                flex: 3,
                child: SingleChildScrollView(
                    child: MaterialPage(message, image, myData))),
            Expanded(
              flex: 4,
              child: Answer(
                myData: myData,
              ),
            )
          ],
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class MaterialPage extends StatelessWidget {
  String message;
  String image;
  var myData;
  MaterialPage(this.message, this.image, this.myData);
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          width: 300.0,
          height: 100.0,
          child: ClipRect(
            child: Image(
              image: AssetImage(image),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 15.0),
          child: Center(
            child: Text(
              message,
              style: TextStyle(fontSize: 15.0, fontFamily: 'Quando'),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              child: OutlineButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => HomePage(),
                  ));
                },
                child: Text(
                  'continue',
                  style: TextStyle(
                    fontSize: 18.0,
                  ),
                ),
                padding: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                borderSide: BorderSide(
                  width: 3.0,
                  color: Colors.indigo,
                ),
                splashColor: Colors.indigoAccent,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ignore: must_be_immutable
class Answer extends StatelessWidget {
  var myData;
  Answer({this.myData});
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 9,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                "${myData[0][index.toString()]}",
                style: TextStyle(fontSize: 25, color: Colors.red),
              ),
              Text(
                "${myData[2][index.toString()]}",
                style: TextStyle(color: Colors.green, fontSize: 20),
              ),
            ],
          ),
        );
      },
    );
  }
}
