import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'home.dart';

// ignore: must_be_immutable
class AboutApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: missing_return
      onWillPop: () {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => HomePage()));
      },
      child: SafeArea(
        child: Scaffold(
          body: FutureBuilder(
              future: DefaultAssetBundle.of(context)
                  .loadString('assets/about.json'),
              builder: (context, snapshot) {
                var myData = jsonDecode(snapshot.data.toString());
                if (myData == null) {
                  return Scaffold(
                    body: Center(
                      child: Text(
                        "loading",
                      ),
                    ),
                  );
                } else {
                  return Column(
                    children: <Widget>[
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 5.0, bottom: 5.0),
                          child: Text(
                            "نبذة عن التطبيق ",
                            style: TextStyle(
                                color: Colors.red,
                                fontSize: 25,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 8,
                        child: BodyText(myData),
                      ),
                      RaisedButton(
                        color: Colors.green,
                        child: Text("الصفحة الرئيسية"),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => HomePage()));
                        },
                      ),
                    ],
                  );
                }
              }),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class BodyText extends StatelessWidget {
  var myData;
  BodyText(this.myData);
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 4,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            alignment: Alignment.centerRight,
            child: Text(
              "${myData[index]}",
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20.0),
            ),
          ),
        );
      },
    );
  }
}
